import { View, StyleSheet, Pressable } from "react-native";
import React, { useEffect, useState } from "react";
import { Audio } from "expo-av";
import prettyMilliseconds from "pretty-ms";
import { Text } from "react-native";
import { useNavigation } from "expo-router";
const index = () => {
  const navigation = useNavigation();
  const [isRecording, setIsRecording] = useState(false);
  const [recording, setRecording] = useState<any>();
  const [permissionResponse, requestPermission] = Audio.usePermissions();
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    getPermission();
  }, []);

  const getPermission = async () => {
    if (permissionResponse?.status !== "granted") {
      await requestPermission();
    }
  };

  const startRecording = async () => {
    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      const { recording } = await Audio.Recording.createAsync(
        Audio.RecordingOptionsPresets.HIGH_QUALITY
      );

      recording.setOnRecordingStatusUpdate((status) =>
        setCurrentTime(status.durationMillis)
      );
      setRecording(recording);
    } catch (err) {
      console.error("Failed to start recording", err);
    }
  };

  const stopRecording = async () => {
    try {
      setRecording(undefined);
      await recording.stopAndUnloadAsync();
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
      });
      const uri = recording.getURI();
      navigation.navigate("preview", { uri });
    } catch (error) {
      console.log("🚀 ~ file: index.tsx:52 ~ stopRecording ~ error:", error);
    }
  };

  return (
    <View style={styles.main}>
      <Text>
        {prettyMilliseconds(currentTime, {
          colonNotation: true,
        })}
      </Text>
      <Pressable
        onPress={() => {
          setIsRecording(!isRecording),
            isRecording ? stopRecording() : startRecording();
        }}
        style={styles.recordContainer}
      >
        {isRecording ? (
          <View style={[styles.pauseButton]} />
        ) : (
          <View style={[styles.recordButton]} />
        )}
      </Pressable>
    </View>
  );
};

export default index;

const styles = StyleSheet.create({
  main: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  recordContainer: {
    width: 60,
    height: 60,
    padding: 6,
    borderRadius: 100,
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    bottom: 10,
  },
  recordButton: {
    width: 50,
    height: 50,
    backgroundColor: "red",
    borderRadius: 25,
  },
  pauseButton: {
    width: 30,
    height: 30,
    backgroundColor: "red",
    borderRadius: 4,
  },
});
