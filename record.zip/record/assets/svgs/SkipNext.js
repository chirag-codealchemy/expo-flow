import * as React from "react";
import Svg, { G, Path } from "react-native-svg";
/* SVGR has dropped some elements not supported by react-native-svg: title */
export const SkipNext = (props) => (
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    width={24}
    height={24}
    viewBox="0 0 48 48"
    {...props}
  >
    <G data-name="Layer 2">
      <Path fill="none" d="M0 0h48v48H0z" data-name="invisible box" />
      <G data-name="icons Q2">
        <Path d="M34 10a2 2 0 0 0-2 2v24a2 2 0 0 0 4 0V12a2 2 0 0 0-2-2ZM15.5 10.6a2.1 2.1 0 0 0-2.7-.2 1.9 1.9 0 0 0-.2 3L23.2 24 12.6 34.6a1.9 1.9 0 0 0 .2 3 2.1 2.1 0 0 0 2.7-.2l11.9-12a1.9 1.9 0 0 0 0-2.8Z" />
      </G>
    </G>
  </Svg>
);
