import {
  Text,
  View,
  StyleSheet,
  SafeAreaView,
  Image,
  Dimensions,
} from "react-native";
import prettyMilliseconds from "pretty-ms";

import Slider from "@react-native-community/slider";

const CustomSlider = ({ start, end, current, onChange }) => {
  return (
    <View style={styles.slider_view}>
      <Text style={styles.slider_time}>
        {prettyMilliseconds(start, { colonNotation: true })}{" "}
      </Text>
      <Slider
        value={current}
        maximumValue={end}
        minimumValue={start}
        onValueChange={onChange}
        thumbTintColor="#e75480"
        style={styles.slider_style}
        minimumTrackTintColor="#e75480"
        maximumTrackTintColor="#d3d3d3"
      />
      <Text style={styles.slider_time}>
        {prettyMilliseconds(end, { colonNotation: true })}
      </Text>
    </View>
  );
};

export default CustomSlider;

const styles = StyleSheet.create({
  image_view: {
    height: "100%",
    width: "50%",
    borderRadius: 10,
  },
  name_of_song_View: {
    height: "15%",
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  name_of_song_Text1: {
    fontSize: 19,
    fontWeight: "500",
  },
  name_of_song_Text2: {
    color: "#808080",
    marginTop: "4%",
  },
  slider_view: {
    height: 20,
    width: "100%",
    alignItems: "center",
    flexDirection: "row",
  },
  slider_style: {
    height: "70%",
    width: "70%",
  },
  slider_time: {
    fontSize: 15,
    marginLeft: "6%",
    color: "#808080",
  },
  functions_view: {
    flexDirection: "row",
    height: "10%",
    width: "100%",
    alignItems: "center",
  },
  recently_played_view: {
    height: "25%",
    width: "100%",
  },
  recently_played_text: {
    fontWeight: "bold",
    fontSize: 16,
    color: "#808080",
    marginLeft: "5%",
    marginTop: "6%",
  },
  recently_played_list: {
    backgroundColor: "#FFE3E3",
    height: "50%",
    width: "90%",
    borderRadius: 10,
    marginLeft: "5%",
    marginTop: "5%",
    alignItems: "center",
    flexDirection: "row",
  },
  recently_played_image: {
    height: "80%",
    width: "20%",
    borderRadius: 10,
  },
  recently_played_list_text: {
    height: "100%",
    width: "60%",
    justifyContent: "center",
  },
  recently_played_list_text1: {
    fontSize: 15,
    marginLeft: "8%",
  },
  recently_played_list_text2: {
    fontSize: 16,
    color: "#808080",
    marginLeft: "8%",
  },
});
