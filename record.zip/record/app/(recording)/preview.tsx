import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import React, { useEffect, useState } from "react";
import CustomSlider from "@/components/Slider";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRoute } from "@react-navigation/native";
import { Audio } from "expo-av";
import { PauseSvg, PlaySound, SkipNext, SkipPrevious } from "@/assets/svgs";
import { moderateScale } from "react-native-size-matters";

const preview = () => {
  const route = useRoute();
  const { uri } = route?.params;
  const [isLoading, setIsLoading] = useState(true);
  const [totalTime, setTotalTime] = useState(0);
  const [sound, setSound] = useState();
  const [isSoundPlaying, setIsSoundPlaying] = useState(false);
  const [curentTime, setCurentTime] = useState(0);

  useEffect(() => {
    getAudioDetail();
  }, []);

  const getAudioDetail = async () => {
    const { sound: storeSound } = await Audio.Sound.createAsync({ uri });
    setSound(storeSound);
    storeSound
      .getStatusAsync()
      .then((data) => setTotalTime(data?.playableDurationMillis))
      .catch((err) => Alert.alert(err));
    setIsLoading(false);
  };

  const playSound = async () => {
    try {
      await sound.playAsync();
      setIsSoundPlaying(true);
    } catch (error) {
      console.log("🚀 ~ file: preview.tsx:35 ~ playSound ~ error:", error);
    }
  };

  const pauseSound = async () => {
    try {
      await sound.pauseAsync();
      setIsSoundPlaying(false);
    } catch (error) {
      console.log("🚀 ~ file: preview.tsx:35 ~ playSound ~ error:", error);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1 }} edges={["top"]}>
      {isLoading ? (
        <View style={{ alignSelf: "center" }}>
          <Text>Loading...</Text>
        </View>
      ) : (
        <View style={styles.main}>
          {/* <CustomSlider end={totalTime} start={} /> */}
          <View style={styles.soundControllerContainer}>
            <SkipPrevious />
            <Pressable onPress={isSoundPlaying ? pauseSound : playSound}>
              {isSoundPlaying ? <PauseSvg /> : <PlaySound />}
            </Pressable>
            <SkipNext />
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

export default preview;

const styles = StyleSheet.create({
  main: {
    flex: 1,
    gap: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  soundControllerContainer: {
    alignSelf: "center",
    width: moderateScale(200),
    flexDirection: "row",
    justifyContent: "space-between",
  },
});
